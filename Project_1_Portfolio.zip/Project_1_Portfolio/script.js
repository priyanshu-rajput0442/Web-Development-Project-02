const $ = (selector) => document.querySelector(selector);
const STORAGE_KEY = "pr_portfolio_messages_v1";
const THEME_KEY = "pr_portfolio_theme_v1";

// Demo-only credentials: change these before presenting the project.
const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "portfolio123";

function readMessages() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function showMessages() {
  const container = $("#responsesList");
  const messages = readMessages().slice().reverse();
  container.replaceChildren();
  if (!messages.length) {
    const empty = document.createElement("p");
    empty.className = "small-note";
    empty.textContent = "No messages have been submitted yet.";
    container.append(empty);
    return;
  }
  messages.forEach((item) => {
    const card = document.createElement("article");
    card.className = "response-card";
    const title = document.createElement("h3");
    title.textContent = item.name;
    const meta = document.createElement("p");
    meta.className = "meta";
    meta.textContent = `${item.email} · ${item.timestamp}`;
    const message = document.createElement("p");
    message.textContent = item.message;
    card.append(title, meta, message);
    container.append(card);
  });
}

$("#themeToggle").addEventListener("click", () => {
  const isDark = document.body.classList.toggle("dark");
  localStorage.setItem(THEME_KEY, isDark ? "dark" : "light");
  $("#themeToggle").textContent = isDark ? "☀" : "☾";
});
if (localStorage.getItem(THEME_KEY) === "dark") {
  document.body.classList.add("dark");
  $("#themeToggle").textContent = "☀";
}

$("#menuToggle").addEventListener("click", () => $("#navigation").classList.toggle("open"));
$("#navigation").querySelectorAll("a").forEach((link) => link.addEventListener("click", () => $("#navigation").classList.remove("open")));

const emailInput = $("#email");
function validEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value.trim());
}
emailInput.addEventListener("input", () => {
  $("#emailError").textContent = emailInput.value && !validEmail(emailInput.value) ? "Please enter a valid email address, such as name@example.com." : "";
});

$("#contactForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const name = $("#name").value.trim();
  const email = emailInput.value.trim();
  const message = $("#message").value.trim();
  $("#formStatus").textContent = "";
  if (!name || !message) {
    $("#formStatus").textContent = "Please complete all fields.";
    return;
  }
  if (!validEmail(email)) {
    $("#emailError").textContent = "Please enter a valid email address.";
    emailInput.focus();
    return;
  }
  const messages = readMessages();
  messages.push({ name, email, message, timestamp: new Date().toLocaleString() });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
  $("#contactForm").reset();
  $("#emailError").textContent = "";
  $("#formStatus").textContent = "Thanks! Your message was saved in this browser.";
});

$("#loginForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const username = $("#username").value.trim();
  const password = $("#password").value;
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    $("#loginPanel").hidden = true;
    $("#responsesPanel").hidden = false;
    $("#loginStatus").textContent = "";
    showMessages();
  } else {
    $("#loginStatus").textContent = "Those demo credentials do not match. Please try again.";
  }
});
$("#logoutButton").addEventListener("click", () => {
  $("#responsesPanel").hidden = true;
  $("#loginPanel").hidden = false;
  $("#loginForm").reset();
});
$("#clearMessages").addEventListener("click", () => {
  if (window.confirm("Delete all contact messages saved in this browser?")) {
    localStorage.removeItem(STORAGE_KEY);
    showMessages();
  }
});
