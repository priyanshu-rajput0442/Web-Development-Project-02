# Project 1 — Responsive Resume / Portfolio Website

## Features
- Responsive one-page portfolio with Home, About, Skills, Projects and Contact sections
- Sticky navigation with smooth scrolling and mobile menu
- Contact form with email validation
- Contact submissions stored in browser `localStorage` as JSON
- Demo admin login and timestamped response viewer
- Light/dark mode preference saved in `localStorage`

## Run it
1. Extract this folder.
2. Open `index.html` in Chrome, or open the folder in VS Code and use the Live Server extension.
3. Submit a test message, then open Admin.

## Demo admin login
- Username: `admin`
- Password: `portfolio123`

This is a front-end coursework demo, not a secure production login. Messages are stored only in the same browser/device and no real email is sent.

## Before submission
Review the content and replace any personal details or claims that do not describe you. Add a screenshot of the running site and be ready to explain `localStorage`, form validation, theme persistence and the admin demo.
