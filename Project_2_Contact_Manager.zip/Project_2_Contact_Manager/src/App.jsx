import { useMemo, useState } from "react";
import ContactForm from "./components/ContactForm.jsx";
import ContactList from "./components/ContactList.jsx";

const starterContacts = [
  {
    id: 1,
    fullName: "Aarav Sharma",
    role: "UI Designer",
    company: "Northstar Studio",
    phone: "+91 98765 43210",
    email: "aarav@example.com",
    bio: "Turns complex ideas into simple, friendly interfaces.",
    avatar: ""
  },
  {
    id: 2,
    fullName: "Meera Kapoor",
    role: "Frontend Developer",
    company: "Pixel Grove",
    phone: "+91 98765 12340",
    email: "meera@example.com",
    bio: "Enjoys building responsive websites and reusable components.",
    avatar: ""
  },
  {
    id: 3,
    fullName: "Kabir Verma",
    role: "Project Coordinator",
    company: "BrightPath",
    phone: "+91 91234 56780",
    email: "kabir@example.com",
    bio: "Keeps teams organised and projects moving forward.",
    avatar: ""
  }
];

export default function App() {
  const [contacts, setContacts] = useState(starterContacts);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);

  const filteredContacts = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return contacts;
    return contacts.filter((contact) =>
      `${contact.fullName} ${contact.company}`.toLowerCase().includes(term)
    );
  }, [contacts, search]);

  function addContact(newContact) {
    setContacts((current) => [{ ...newContact, id: Date.now() }, ...current]);
    setShowForm(false);
  }

  function deleteContact(id) {
    setContacts((current) => current.filter((contact) => contact.id !== id));
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="logo" href="#top" aria-label="Contactly home"><span>c</span>.</a>
        <div className="topbar-note">A LITTLE DIRECTORY, WELL ORGANISED</div>
        <button className="button button-outline small-button" onClick={() => setShowForm((value) => !value)}>
          {showForm ? "Close form" : "+ Add contact"}
        </button>
      </header>

      <main id="top">
        <section className="intro">
          <div className="intro-copy">
            <p className="eyebrow">YOUR PEOPLE, AT A GLANCE</p>
            <h1>Keep good<br /><span>connections close.</span></h1>
            <p className="intro-text">A simple place to collect the people you work with, remember what they do, and find the right contact in seconds.</p>
          </div>
          <div className="summary-card">
            <span className="summary-icon">✳</span>
            <p className="summary-label">CONTACTS IN YOUR LIST</p>
            <strong>{contacts.length.toString().padStart(2, "0")}</strong>
            <span className="summary-caption">and counting</span>
          </div>
        </section>

        {showForm && <ContactForm onAdd={addContact} onCancel={() => setShowForm(false)} />}

        <section className="directory">
          <div className="directory-heading">
            <div><p className="eyebrow">THE DIRECTORY</p><h2>Your contacts <span className="count-pill">{filteredContacts.length}</span></h2></div>
            <label className="search-box">
              <span aria-hidden="true">⌕</span>
              <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search name or company..." aria-label="Search contacts by name or company" />
              {search && <button type="button" onClick={() => setSearch("")} aria-label="Clear search">×</button>}
            </label>
          </div>
          <ContactList contacts={filteredContacts} onDelete={deleteContact} />
          {filteredContacts.length === 0 && <div className="empty-state"><span>⌕</span><h3>No matching contacts</h3><p>Try another name or company, or add a new contact.</p></div>}
        </section>
      </main>
      <footer><span>CONTACTLY / FRONT-END CAPSTONE</span><span>Built with React · Components · Hooks</span></footer>
    </div>
  );
}