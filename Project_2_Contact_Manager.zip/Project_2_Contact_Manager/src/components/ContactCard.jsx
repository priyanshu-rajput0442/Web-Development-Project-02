function initials(name) {
  return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]?.toUpperCase() || "").join("");
}

export default function ContactCard({ contact, onDelete }) {
  return (
    <article className="contact-card">
      <div className="card-topline"><span className="contact-type">CONTACT CARD</span><button className="delete-button" type="button" onClick={() => onDelete(contact.id)} aria-label={`Delete ${contact.fullName}`} title="Delete contact">×</button></div>
      <div className="person">
        {contact.avatar ? <img className="avatar" src={contact.avatar} alt={`${contact.fullName}'s avatar`} onError={(event) => { event.currentTarget.style.display = "none"; }} /> : <div className="avatar initials">{initials(contact.fullName)}</div>}
        <div><h3>{contact.fullName}</h3><p className="role">{contact.role}</p><p className="company">{contact.company}</p></div>
      </div>
      {contact.bio && <p className="bio">{contact.bio}</p>}
      <div className="contact-details">
        {contact.email && <a href={`mailto:${contact.email}`}><span>✉</span>{contact.email}</a>}
        {contact.phone && <a href={`tel:${contact.phone.replace(/[^\d+]/g, "")}`}><span>↗</span>{contact.phone}</a>}
      </div>
    </article>
  );
}