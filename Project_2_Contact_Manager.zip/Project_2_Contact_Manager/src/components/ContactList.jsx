import ContactCard from "./ContactCard.jsx";

export default function ContactList({ contacts, onDelete }) {
  return (
    <div className="contact-grid">
      {contacts.map((contact) => <ContactCard key={contact.id} contact={contact} onDelete={onDelete} />)}
    </div>
  );
}