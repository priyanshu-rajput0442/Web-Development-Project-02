import { useState } from "react";

const initialForm = {
  fullName: "", role: "", company: "", phone: "", email: "", bio: "", avatar: ""
};

export default function ContactForm({ onAdd, onCancel }) {
  const [form, setForm] = useState(initialForm);
  const [error, setError] = useState("");

  function update(event) {
    setForm((current) => ({ ...current, [event.target.name]: event.target.value }));
  }

  function submit(event) {
    event.preventDefault();
    if (!form.fullName.trim() || !form.company.trim()) {
      setError("Please enter at least a name and company.");
      return;
    }
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim())) {
      setError("Please enter a valid email address.");
      return;
    }
    onAdd({
      ...form,
      fullName: form.fullName.trim(),
      company: form.company.trim(),
      role: form.role.trim() || "Contact",
      email: form.email.trim(),
      bio: form.bio.trim()
    });
    setForm(initialForm);
    setError("");
  }

  return (
    <section className="form-panel">
      <div className="form-panel-heading"><div><p className="eyebrow">NEW CONNECTION</p><h2>Add a contact</h2></div><p>Fields marked by the form are kept simple for quick entry.</p></div>
      <form className="contact-form" onSubmit={submit}>
        <label>Full name *<input name="fullName" value={form.fullName} onChange={update} placeholder="e.g. Riya Singh" required /></label>
        <label>Job title<input name="role" value={form.role} onChange={update} placeholder="e.g. Product Designer" /></label>
        <label>Company *<input name="company" value={form.company} onChange={update} placeholder="e.g. Studio North" required /></label>
        <label>Phone<input name="phone" value={form.phone} onChange={update} placeholder="+91 ..." /></label>
        <label>Email<input name="email" type="email" value={form.email} onChange={update} placeholder="name@example.com" /></label>
        <label>Avatar image URL<input name="avatar" type="url" value={form.avatar} onChange={update} placeholder="https://..." /></label>
        <label className="wide-field">Short bio<textarea name="bio" value={form.bio} onChange={update} rows="3" placeholder="A short note about this person..." /></label>
        {error && <p className="form-error wide-field" role="alert">{error}</p>}
        <div className="form-actions wide-field"><button className="button button-primary" type="submit">Save contact ↗</button><button className="button button-outline" type="button" onClick={onCancel}>Cancel</button></div>
      </form>
    </section>
  );
}