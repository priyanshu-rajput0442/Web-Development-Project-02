# Project 2 — React Contact Cards Manager

## Features
- React single-page app with `App`, `ContactForm`, `ContactCard` and `ContactList` components
- `useState` manages the contact array, form fields and search input
- Add contact cards without refreshing the page
- Responsive card grid and search by name or company (case-insensitive)
- Optional avatar URL, mail links, phone links and delete action
- Basic validation for name, company and email

## Requirements
Install Node.js (LTS) first. Internet access is needed the first time to install packages.

## Run in VS Code
1. Extract the folder and open `Project_2_Contact_Manager` in VS Code.
2. Open Terminal → New Terminal.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local address printed by Vite (usually `http://localhost:5173`).

To test a production build, run `npm run build`.

## Notes for submission
The three example contacts are sample data. Add a contact of your own to demonstrate the form, and try searching by a partial name or company. Read the components and be ready to explain how props, `useState`, and filtering work. Replace sample text or design details with your own choices before submitting.
